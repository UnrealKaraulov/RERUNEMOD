# Runemod Reloaded

Adding items and / or runes to CS 1.6 


Installing:

1. Compile
2. Copy cstrike dir to server
3. Copy plugins
4. Copy plugins-RunemodReloaded.ini

Warning! If you install it to plugins.ini, place all rm_ plugins only after other and admin plugins! 
